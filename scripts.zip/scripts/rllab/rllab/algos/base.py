class Algorithm(object):
    pass


class RLAlgorithm(Algorithm):

    def train(self):
        raise NotImplementedError
